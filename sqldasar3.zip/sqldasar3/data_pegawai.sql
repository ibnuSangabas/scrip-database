INSERT INTO pegawai (id_pegawai, nama_depan, nama_belakang, email, telepon, tanggal_kontrak, id_job, gaji, tunjangan)
VALUES ('E001', 'Ferry', 'Gustiawan', 'ferry@yahoo.com', '07117059004', '2005-09-01', 'L0001', '2000000', '500000'),
('E002', 'Aris', 'Ganiardi', 'aris@yahoo.com', '081312345678', '2006-09-01', 'L0002', '2000000', '200000'),
('E003', 'Faiz', 'Ahmad', 'faiz@gmail.com', '081367384322', '2006-10-01', 'L0003', '1500000' , 'NULL'),
('E004', 'Emma', 'Bunton', 'emma@gmail.com', '081363484342', '2006-10-01', 'L0004', '1500000', '0'),
('E005', 'Mike', 'Scoff', 'mike@plasa.com', '08163454555', '2007-09-01', 'L0005', '1250000', '0'),
('E061', 'Lincoln', 'Burrous', 'linc@yahoo.com', '08527388432', '2008-09-01', 'L0006', '1750000', 'NULL');
