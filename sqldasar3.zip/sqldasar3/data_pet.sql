INSERT INTO pet ( name, owner, species, sex, birth, death)
VALUES ( 'Puffball', 'Diane', 'Hamster', 'f', '1999-03-03', 'NULL '),
('Claws', 'Gwen', 'Cat', 'm', '1994-03-17', 'NULL '),
('Fluffy', 'Harold', 'Cat', 'f', '1993-02-04', 'NULL '),
('Buffy', 'Harold', 'Dog', 'f', '1989-05-13', 'NULL  '),
('Fang', 'Benny', 'Dog', 'm', '1990-08-27', 'NULL '),
('Bowser', 'Diane', 'Dog', 'm', '1989-08-31', '1995-07-29 '),
('Chirpy', 'Gwen', 'Bird', 'f', '1998-09-11', 'NULL '),
('Whistler', 'Gwen', 'Bird', 'NULL ', '1997-12-09', 'NULL '),
('Slim', 'Benny', 'Snake', 'f', '1996-04-29', 'NULL ');