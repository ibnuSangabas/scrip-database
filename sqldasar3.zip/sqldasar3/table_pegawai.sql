CREATE TABLE pegawai (id_pegawai VARCHAR(10) PRIMARY KEY,
nama_depan VARCHAR(20), 
nama_belakang VARCHAR(30),
email VARCHAR(35),
telepon INT(20),
tanggal_kontrak VARCHAR(25),
id_job VARCHAR(20),
gaji INT(30),
tunjangan VARCHAR(30) );