CREATE TABLE pet (name VARCHAR(20),
owner VARCHAR(20),
species VARCHAR(20),
sex VARCHAR(20),
birth VARCHAR(30),
death VARCHAR(30)NOT NULL);