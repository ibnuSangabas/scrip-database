insert into mobil (kode, jenis, merk, tarif, nopol)
	values('M001', 'SEDAN', 'BMW E5', '500000', 'BG1234AA'),
	('M002', 'SEDAN', 'HONDA CRV', '350000', 'BG2345BB'),
	('M003', 'BUS', 'MERCEDEZ', '1000000', 'BG3456CC'),
	('M004', 'BUS', 'DYNA', '800000', 'BG8433DD'),
	('M005', 'TRUCK', 'HYNO ZX', '1500000', 'BG4638EE'),
	('M006', 'TRUCK', 'DYNA X1', '1500000', 'BG8473FF');