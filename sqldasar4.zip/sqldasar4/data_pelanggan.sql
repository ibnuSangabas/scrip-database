insert into pelanggan (kode, nama, kontak, alamat, kota, kodepos, telepon)
	values('P001', 'PT FOX RIVER', 'HENDRA', 'JL. JEND. SUDIRMAN 657', 'BENGKULU', '30245', '1234567'),
	('P002', 'CV FOXCON', 'IWAN', 'JL. WAHID HASYIM 743', 'JAKARTA', '73429', '234567'),
	('P003', 'PT FARMACON', 'YANI', 'JL. AHMAD DAHLAN 45', 'LAMPUNG', '28349', '3334445');