insert into sewa (nofaktursewa, kodepelanggan, tglsewa, kodemobil, lamasewa, uangmuka)
	values ('F001', 'P001', '2008-12-01', 'M001', '2', '200000'),
	('F001', 'P001', '2008-12-01', 'M003', '2', '200000'),
	('F003', 'P002', '2008-12-02', 'M002', '1', '100000');