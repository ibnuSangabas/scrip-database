create table pelanggan ( 
kode varchar(15) not null,
nama varchar(25) not null,
kontak varchar(15) not null,
alamat varchar(40) not null,
kota varchar(20) not null,
kodepos int(10) not null,
telepon int(15) not null,
primary key(kode)
);