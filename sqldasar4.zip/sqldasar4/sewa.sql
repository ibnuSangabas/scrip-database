create table sewa (
nofaktursewa varchar(15) not null,
kodepelanggan varchar(15) ,
tglsewa varchar(25),
kodemobil varchar(15) not null,
lamasewa varchar(5),
uangmuka varchar(20)
);