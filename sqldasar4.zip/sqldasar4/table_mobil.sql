create table mobil (
kode varchar(15) not null,
jenis varchar(15) not null,
merk varchar(20) not null,
tarif varchar(20) not null,
nopol varchar(20) not null,
primary key(kode)
);